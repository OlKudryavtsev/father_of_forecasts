"""Father Predictions bot package."""
